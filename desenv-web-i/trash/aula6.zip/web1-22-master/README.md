# Desenvolvimento Web I
- Site tutorial: https://fscheidt.github.io/site
- Moodle (fazer inscrição): https://ava.ifpr.edu.br/enrol/index.php?id=8670

## Sábados letivos:
<details>
<summary><b>14/05 ✔</b></summary>
Atividades assíncronas: 
<ul>
<li>lista de exercícios slide 2, sobre listas ordenadas, sublistas
<li>ver pasta /aulas/aula02
<li>enviar para: felippe.scheidt@ifpr.edu.br
<li>entrega: 24/05
</details>

## Ambiente de desenvolvimento

### Editor
- Visual studio code

### Navegadores recomendados
- Firefox
- Chromium (Chrome, Brave)

### Rodar o linux (máquina virtual)
Para executar o Linux como máquina virtual dentro do Windows, existem as seguintes opções:
1. Instalar: Virtual Box
1. WSL (nativo do windows)
